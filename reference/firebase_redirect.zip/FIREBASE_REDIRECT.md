# Epitome QR redirect via Firebase Hosting

Purpose: give the printed book (and anything else) a permanent address
the business controls — e.g. epitome-leadership.com/assessment — that
forwards to the current SurveyMonkey collector. If the survey ever
moves, only this redirect changes; printed QR codes keep working.

Current destination: https://www.surveymonkey.com/r/EpitomeGuide
(302 = temporary redirect, deliberately: phones/browsers won't cache it
permanently, so it stays changeable. Do not "upgrade" it to 301.)

## Deploy (Claude Code / Samantha)
1. npm install -g firebase-tools
2. firebase login            (owner's Google account)
3. firebase projects:create epitome-assessment   (or use existing; then
   firebase use <project-id>)
4. From this folder: firebase deploy --only hosting
5. Test the Google-issued URL it prints (…web.app): it must land on the
   SurveyMonkey assessment.

## Custom domain (needs domain admin access)
Firebase console -> Hosting -> Add custom domain -> e.g.
go.epitome-leadership.com (a subdomain is easiest; a path on the main
site like /assessment requires the redirect to live on whatever hosts
the main site instead). Firebase shows DNS records to add at the domain
registrar; verification can take up to a day.

## Before printing any QR code
- Confirm the survey behind the link has all 12 questions incl. Power
  and Ambition, collector Open, no cutoff/limit.
- Generate the QR from the FINAL owned address (not the web.app URL),
  print a test page, scan with iPhone + Android, complete a test
  response end-to-end (then exclude it from real results).
